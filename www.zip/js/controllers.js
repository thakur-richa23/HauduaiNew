angular.module('starter.controllers', ['filters'])

.controller('AppCtrl', function($scope, $ionicModal, $timeout,$state,$http,$ionicSideMenuDelegate,$ionicHistory,$rootScope, $location) {

 
  $scope.loginData = {};
  $scope.downbutton=true;
  $scope.closebutton=false;
  $scope.showdr=false;
  
  
	$scope.showdrop=function(){
		if($scope.showdr==false){
			$scope.showdr=true;
			$scope.downbutton=false;
			$scope.closebutton=true;
		}else{
			$scope.showdr=false;
			$scope.downbutton=true;
			$scope.closebutton=false;
		}
	}

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
	 // console.log($scope.loginData);
    var name=$scope.loginData.username;
	var password=$scope.loginData.password;
	
    
    $http.get("http://api.hauduai.com.ng/hauduailogin?username="+name+"&password="+password)
	.success(function(response){
		window.location.href='/#/app/browse';
	localStorage.setItem("signed",true);
	localStorage.setItem("loggedin",response.first_name);
	localStorage.setItem("userid",response.id);
	localStorage.setItem("useremail",response.email);
	$scope.closeLogin();
	

	})
		.error(function(){
		alert("Somthing Went Wrong");
		})
	};
})

.controller('PlaylistsCtrl', function($scope,$state) {
  
  
})

.controller('PlaylistCtrl', function($scope, $stateParams) {
})
.controller('dropdown', function($scope, $stateParams, $ionicModal, $http,$ionicLoading,$timeout,$location) {
	
	 $scope.shownto=true;
	$scope.hidet=false;
	//$scope.change_input=true;
	
	$scope.change_input=function(){
		//alert($scope.shownto);
		if($scope.shownto==true){
			
			$scope.hidet=true;
			$scope.shownto=false;
		}
		else if($scope.shownto==false){
		 $scope.shownto=true;
			$scope.hidet=false;
	    }
		
	}
	
	
	/* $scope.change_input=function(){
			$scope.hidet=false;
	    $scope.shownto=true;
	} */
	
	 
		$http.get("http://api.hauduai.com.ng/suffix")
		.success(function(response){
			$scope.suffix=response;
		 
		})
		
		
		$http.get ("http://api.hauduai.com.ng/employment_status")
		.success(function(response){
			$scope.employment_status=response;
		})
		
	 /* $scope.subsector="Bussiness Sector"; */
	//$scope.emp_status="Employment Status";
	/*$scope.subsubsector="Bussiness Sub Sector";
	$scope.subproffession="Profession";
	$scope.prof_affi="Profession Affiliation";
	$scope.prof_sub="Profession Sub Category"; */
	
	$http.get("http://api.hauduai.com.ng/sector")
	.success(function(response){
		$scope.sector=response;
		
		
		
	})
	$http.get("http://api.hauduai.com.ng/profession")
	.success(function(response){
		$scope.profession=response;
		
		
		
	})
	$scope.getsubprofession=function(){
		  $ionicLoading.show({
    content: 'Loading',
    animation: 'fade-in',
    showBackdrop: true,
    maxWidth: 200,
    showDelay: 0,
	
  });
   $timeout(function () { 
    
  
	$http.get("http://api.hauduai.com.ng/profession_subcategory?id="+$scope.subprofession)
	.success(function(response){
		$scope.profession_subcategory=response;
		
		$ionicLoading.hide();
		
	})
	
   }, 2000);
	} 
	
	
	
	
	
	
	
	
	/*  $scope.afflicap=true;
	$scope.ends=false;
	$scope.chang_inputt=function(){
	$scope.ends=true;
	    $scope.afflicap=false;
		
	} */
	
	 $scope.afflicap=true;
	$scope.ends=false;
	//$scope.change_input=true;
	
	$scope.chang_inputt=function(){
		//alert($scope.shownto);
		if($scope.afflicap==true){
			
			$scope.ends=true;
			$scope.afflicap=false;
		}
		else if($scope.afflicap==false){
		 $scope.afflicap=true;
			$scope.ends=false;
			
	    }
		
	}
	
	
	$http.get("http://api.hauduai.com.ng/profession_affi")
	.success(function(response){
		$scope.profession_affi=response;
			//console.log(response);
	})
	
	
	
	$scope.getsubsector=function(){
		  $ionicLoading.show({
    content: 'Loading',
    animation: 'fade-in',
    showBackdrop: true,
    maxWidth: 200,
    showDelay: 0,
	
  });
   $timeout(function () {
    
	$http.get("http://api.hauduai.com.ng/sector_subcategories?id="+$scope.subsector)
	.success(function(response){
		$scope.sector_subcategories=response;
		
		$ionicLoading.hide();
		
	})
	
  }, 2000);
	}
	
	
	$http.get("http://api.hauduai.com.ng/know_about_hauduai")
	.success(function(response){
		$scope.know_about_hauduai=response;
	})
	/* $scope.getsubsubsector=function(){
		  $ionicLoading.show({
    content: 'Loading',
    animation: 'fade-in',
    showBackdrop: true,
    maxWidth: 200,
    showDelay: 0,
	
  });
   $timeout(function () {
    
    
	$http.get("http://api.hauduai.com.ng/sector_subsubcategories?id="+$scope.subsubsector)
	.success(function(response){
		$scope.sector_subsubcategories=response;
		
		$ionicLoading.hide();
		
	})
	
  }, 2000);
	} */
	
	
	
	
	
	$scope.Submit=function(){
		if($scope.cpassword==$scope.password){
			var fname=$scope.fname;
			var type="Specialist";
			
			var lname=$scope.lname;
			var fullname=fname+" "+lname;
			var qualified=$scope.qualified;
			//var quali=$scope.quali;
			var emp_status=$scope.emp_status;
			var proaffi=$scope.proaffi;
			
			var sector=$scope.subsector;
			var subsector=$scope.subsubsector;
			
			var profession=$scope.subprofession;
			var sub_profession=$scope.prof_sub;
			var email=$scope.email;
			var pass=$scope.password;
			var gettoknow=$scope.gettoknow;
			
			$http.get("http://api.hauduai.com.ng/hauduai_signup?type="+type+"&first_name="+fname+"&last_name="+lname+"&full_name="+fullname+"&Suffix="+qualified+"&employment_status="+emp_status+"&bussiness_sector="+sector+"&bussiness_sector_sub="+subsector+"&profession="+profession+"&profession_sub="+sub_profession+"&email="+email+"&password="+pass+"&know_hauduai="+gettoknow+"&proaffi="+proaffi)
				.success(function(response){
					alert("You are registered Successfully.");
					$location.path('/#/playlists');
				})
				.error(function(){
						alert("Something went Wrong.");
						//alert("You have Registered already.");
						//$location.path('/#/playlists');
				})
			}else{
				alert("Something went Wrong.");
				//$location.path('/#/playlists');
			}
			
		
	}
	/*  $ionicModal.fromTemplateUrl('templates/register.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });
	$scope.closebtn=function(){
		$scope.modal.show();
	};  */
	
	
})

.controller('registerspecialist', function($scope, $stateParams,$http,$ionicLoading,$timeout, $location) {
	/* $scope.show=true;
	$scope.hideme=false;
	$scope.change_input=function(){
			$scope.hideme=true;
	    $scope.show=false;
		
	} */
	 $scope.show=true;
	$scope.hideme=false;
	//$scope.change_input=true;
	
	$scope.change_input=function(){
		//alert($scope.shownto);
		if($scope.show==true){
			
			$scope.hideme=true;
			$scope.show=false;
			$scope.qulaity='';
		}
		else if($scope.show==false){
		 $scope.show=true;
			$scope.hideme=false;
	    }
		
	}
	
	$http.get("http://api.hauduai.com.ng/suffix")
		.success(function(response){
			$scope.suffix=response;
		})
		
		
		$http.get ("http://api.hauduai.com.ng/employment_status")
		.success(function(response){
			$scope.employment_status=response;
		})
		/*  $scope.showmee=true;
	$scope.hide=false;
	$scope.chang_inputt=function(){
	$scope.hide=true;
	    $scope.showmee=false;
		
	} */
		$scope.showmee=true;
	    $scope.hide=false;
		$scope.chang_inputt=function(){
		//alert($scope.shownto);
		if($scope.showmee==true){
			
			$scope.hide=true;
			$scope.showmee=false;
			$scope.pro_affi='';
		}
		else if($scope.showmee==false){
		 $scope.showmee=true;
			$scope.hide=false;
			
	    }
		
	}
	$http.get("http://api.hauduai.com.ng/profession_affi")
	.success(function(response){
		$scope.profession_affi=response;
			
	})
	$http.get("http://api.hauduai.com.ng/spec_area")
	.success(function(response){
		$scope.spec_area=response;
			
	})
	
	$scope.getsubspe_area=function(){
		  $ionicLoading.show({
    content: 'Loading',
    animation: 'fade-in',
    showBackdrop: true,
    maxWidth: 200,
    showDelay: 0,
	
  });
  
   $timeout(function () {
   
    
	$http.get("http://api.hauduai.com.ng/spec_sub_area?id="+$scope.spe_area)
	.success(function(response){
		$scope.spec_sub_area=response;
		
		$ionicLoading.hide();
		
	})
	
  }, 2000);
	}
	$scope.getsubspe_area2=function(){
		  $ionicLoading.show({
    content: 'Loading',
    animation: 'fade-in',
    showBackdrop: true,
    maxWidth: 200,
    showDelay: 0,
	
  });
  
   $timeout(function () {
    
	  
    
	$http.get("http://api.hauduai.com.ng/spec_sub_area?id="+$scope.spe_area2)
	.success(function(response){
		$scope.spec_sub_area2=response;
		
		$ionicLoading.hide();
		
	})
	
  }, 2000);
	}
          
	$http.get("http://api.hauduai.com.ng/know_about_hauduai")
	.success(function(response){
		$scope.know_about_hauduai=response;
	})
	
	$scope.doSubmit=function(){
		if($scope.cpassword==$scope.password){
			var fname=$scope.fname;
			
			var type="Specialist";
			var lname=$scope.lname;
			var fullname=fname+" "+lname;
			var qulaity=$scope.qulaity;
			var emp_status=$scope.emp_status;
			var spe_area1=$scope.spe_area;
			var spe_subarea1=$scope.spe_area_sub;
			var spe_area2=$scope.spe_area2;
			var spe_subarea2=$scope.spe_area_sub2;
			var pro_aff=$scope.pro_affi;
			
			var email=$scope.email;
			
			var pass=$scope.password;
			var gettoknow=$scope.gettoknow;
			
			$http.get("http://api.hauduai.com.ng/hauduaispecialist_signup?type="+type+"&first_name="+fname+"&last_name="+lname+"&full_name="+fullname+"&qualified="+qulaity+"&employment_status="+emp_status+"&selection_area1="+spe_area1+"&sub_category1="+spe_subarea1+"&selection_area2="+spe_area2+"&sub_category2="+spe_area2+"&email="+email+"&password="+pass+"&know_hauduai="+gettoknow+"&pro_aff="+pro_aff)
				.success(function(response){
					alert("You are registered Successfully.");
					$location.path('/#/playlists');
				})
				.error(function(){
						alert("Something went wrong.");
				}) 
			
			
		}else{
			alert("Something went wrong.");
		}
		
		
	}
	
	
	
})
.controller('newsCtrl', function($scope, $stateParams,$http) {
	$http.get("http://api.hauduai.com.ng/hauduai_news")
	.success(function(response){
		$scope.news=response;
		
	})
	
})
.controller('pollsCtrl', function($scope, $stateParams,$http) {
	
	$http.get("http://api.hauduai.com.ng/hauduaiopen_polls")
	.success(function(response){
		$scope.openpoll=response;
		//console.log(response);
		localStorage.setItem("queid",response[0].id);
		
			$http.get("http://api.hauduai.com.ng/hauduaiopenanswer_polls?id="+response[0].id)
				.success(function(response){
					$scope.openpollanswer=response;
			
			
			
			
			})
			
		
		
	})
	
	$scope.serverSideChange = function(item) {
		var ans_id=item.id;
		var queid=localStorage.getItem("queid");
		var username=localStorage.getItem("loggedin");
		var email=localStorage.getItem("email");
		var userid=localStorage.getItem("userid");
		$http.get("http://api.hauduai.com.ng/hauduaipollsubmit_answer?queid="+queid+"&username="+username+"&email="+email+"&userid="+userid+"&ans_id="+ans_id)
				.success(function(response){
					$scope.openpollanswer=response;
			     })
				 .error(function(response){
					 alert("You have already voted for this qusetion.Your vote not going to be count.");
					 $scope.data.serverSide="";
				 })
	
  };
	
	
	
	
	$http.get("http://api.hauduai.com.ng/hauduai_polls")
	.success(function(response){
		$scope.polls=response;
		
	})
	
})
.controller('pollsresultsCtrl', function($scope, $stateParams,$http,$stateParams) {

		var id=	$stateParams.id;
		var userid=localStorage.getItem("userid");
		$scope.submitt=function(){
			var writecomment=$scope.writecomment;
			$http.get("http://api.hauduai.com.ng/hauduaipolls_writecomment?userid="+userid+"&id="+id+"&comment="+writecomment)
			.success(function(response){
				//$scope.comment_que=response;
				$scope.writecomment="";
				$scope.again();
				
			})
		}
		    $http.get("http://api.hauduai.com.ng/hauduaipollsque_id?id="+id)
			.success(function(response){
				$scope.comment_que=response;
				
			})
			$http.get("http://api.hauduai.com.ng/hauduaipolls_comment?id="+id)
			.success(function(response){
				$scope.comment=response;
				//console.log(response);
				
			})
			$scope.again=function(){
				$http.get("http://api.hauduai.com.ng/hauduaipolls_comment?id="+id)
				.success(function(response){
					$scope.comment=response;
					//console.log(response);
					
				})
			}
	
})
/* .controller('resultpieCtrl', function($scope, $ionicHistory) {
	$scope.labels = ["Download Sales", "In-Store Sales", "Mail-Order Sales"];
   $scope.data = [300, 500, 100];
}) */
.controller('resultpieCtrl', function($scope, $ionicHistory,$stateParams,$http) {
	var id=$stateParams.id;
	
	$http.get("http://api.hauduai.com.ng/totalvotecount?id="+id)
	.success(function(response){
		$scope.totalcount=response[0].count;
		
		
	})
	$http.get("http://api.hauduai.com.ng/hauduaipollsque_id?id="+id)
	.success(function(response){
		$scope.comment_que=response;
		
	})
	$http.get("http://api.hauduai.com.ng/getvoteanswerjoin?id="+id)
	.success(function(response){
		//console.log(response);
		$scope.jointanswer=response;
		
			$scope.getTotal = function(){
				var arr = [];
				for (var x=0; x < response.length ;x++) {
					arr.push(response[x].count);
					
					
				}  
			 var count = 0;
				 
			   for(var i=0;  i < arr.length; i++) 
			   { 
				  count += parseInt(arr[i]); 
			   }
			   $scope.totalvote=count; 
					
			}
	})
	$http.get("http://api.hauduai.com.ng/getvote?id="+id)
	.success(function(response){
		
		
				var arr = [];
				for (var x=0; x < response.length ;x++) {
					arr.push(response[x].countspe);
					
					
				}  
				
			    var i;
			    var g=[];
				for (i = 0; i < arr.length; ++i) {
					g.push(parseInt((parseInt(arr[i])/$scope.totalvote)*100));
					//console.log(g);
					
				}
				
				$scope.data = g; 
				 
	})
	$http.get("http://api.hauduai.com.ng/getvoteanswer?id="+id)
	.success(function(response){
					
				
					var arr = [];
				for (var x=0; x < response.length ;x++) {
					arr.push(response[x].answer);
					
					
				}  
						
				$scope.labels = arr;
				
			  
	
	})
	

	
	
})
.controller('eventsCtrl', function($scope, $ionicHistory,$http,$state) {

  $scope.upcoming=function(){
		$http.get("http://api.hauduai.com.ng/hauduai_events_upcoming")
			.success(function(response){
				$scope.events=response;
		
	    })
	}
	$scope.current=function(){
		$http.get("http://api.hauduai.com.ng/hauduai_events_current")
			.success(function(response){
				$scope.events=response;
		
	    })
	}
	$scope.past=function(){
		$http.get("http://api.hauduai.com.ng/hauduai_events_past")
			.success(function(response){
			 $scope.events=response;
		
	    })
	}  
})
.controller('AllquestionCtrl', function($scope,$http,$ionicHistory,$state) {
	
 var id= localStorage.getItem("userid");
	
		$http.get("http://api.hauduai.com.ng/getaskedquestionsexp?id="+id)
			.success(function(response){
			  
					$scope.communityasked=response;
					
			
		    })
		
		
	
	})
.controller('proCtrl', function($scope,$http,$ionicHistory,$state) {
	
 var id= localStorage.getItem("userid");
	
		$http.get("http://api.hauduai.com.ng/get_all_profile?id="+id)
			.success(function(response){
			 
					$scope.prof=response;
					
		    }) 
			
		
})
	
.controller('AllquestCtrl', function($scope,$http,$ionicHistory,$state) {
	
 var id= localStorage.getItem("userid");
	
		$http.get("http://api.hauduai.com.ng/getaskedquestions?id="+id)
			.success(function(response){
			 
					$scope.communityasked=response;
					
		    }) 
			
		
})
	
	

.controller('ask_specialistCtrl', function($scope, $ionicModal,$ionicHistory,$http) {
	$scope.hello=false;
	$scope.note=false;
		
		$http.get("http://api.hauduai.com.ng/spec_area")
			.success(function(response){
				$scope.specialareamajaor=response;
		
	    })
	
	$scope.changed=function(){
		var id = $scope.quali;
		
		$http.get("http://api.hauduai.com.ng/df?id="+id)
			.success(function(response){
				
				$scope.qualii=response;
		     $scope.note=true;
	    })
	}  
	                           
	$scope.submitt=function(){
		$scope.modal.show();
		$scope.loginData.ques=$scope.que;
	
		
		var quali=$scope.quali;
		var que=$scope.que;
		var sub_field=$scope.sub_field;
		$scope.loginData.username=localStorage.getItem("loggedin");
		$scope.loginData.email=localStorage.getItem("useremail");
		
        //localStorage.setItem("userid",response.id);
        $scope.email= localStorage.getItem("useremail");            
			
			if(typeof(sub_field)!="undefined"){
				$scope.loginData.fieldd=$scope.sub_field;
			}else{
				$scope.loginData.fieldd=$scope.quali;    
			}
		    
			if(typeof(sub_field)!="undefined"){
				
				$http.get("http://api.hauduai.com.ng/user_listby_fieldd?field="+$scope.sub_field)
				.success(function(response){         
					$scope.specialist_user=response;
			        
				})
				  
			}else{
				
				$http.get("http://api.hauduai.com.ng/user_listby_field?field="+$scope.quali)
				.success(function(response){
				  	$scope.specialist_user=response;
			 
				})
			}
			
		$scope.dosubmitque=function(){
				var user_id=localStorage.getItem("userid");
				
				//console.log($scope.loginData.exp);
				 
 				$http.get("http://api.hauduai.com.ng/submit_question_to_specialist?user_id="+user_id+"&que="+$scope.loginData.ques+"&exp_field="+$scope.loginData.fieldd+"&username="+$scope.loginData.username+"&email="+$scope.loginData.email+"&expert="+$scope.loginData.exp)
				 
				.success(function(response){
					if(response.status=="Success"){
						$scope.modal.hide();
						alert("Your Question Has Been Submitted");
					}												
				  
				})
			
 
		}
		
		$scope.get_speci_profile=function(){
			
				$http.get("http://api.hauduai.com.ng/get_spec_profile?id="+$scope.loginData.exp)
				.success(function(response){
					$scope.hello=true;
					$scope.speci_profile=response[0];
				
				})
				$http.get("http://api.hauduai.com.ng/countt?id="+$scope.loginData.exp)
				.success(function(response){
					
					$scope.count=response[0].c;
				})	
				$http.get("http://api.hauduai.com.ng/get_spec_info_to_show?id="+$scope.loginData.exp)
				.success(function(response){
					
					$scope.infoto=response[0];
				})
		}
		          
		         
	}
	
	$ionicModal.fromTemplateUrl('templates/popupForque.html', {
		scope: $scope
    }).then(function(modal) {
		$scope.modal = modal;
	});
	
	$scope.closepop=function(){
	    
		$scope.modal.hide();
		$scope.speci_profile="";
		$scope.count="";
		$scope.loginData.exp="";     
		$scope.sub_field="";
		
	}
	 
})
.controller('ask_communityCtrl', function($scope, $ionicModal,$ionicHistory,$http) {
		
		$http.get("http://api.hauduai.com.ng/profession")
			.success(function(response){
				$scope.profession=response;
				
	    })
		
		$http.get("http://api.hauduai.com.ng/sector")
			.success(function(response){
				$scope.sector_community=response;
		      
	    })
	
	$scope.changed=function(){
		var id = $scope.subprofession;
		$scope.sub_pro_show=true; 
		$http.get("http://api.hauduai.com.ng/profession_subcategory_name?id="+id)
			.success(function(response){
				
				$scope.qualii=response;
		
	    })
	}
	$scope.changedsector=function(){
		var id = $scope.sub_sector_field;
		  $scope.sub_sec_show=true; 
		$http.get("http://api.hauduai.com.ng/sector_subcategories_name?id="+id)
			.success(function(response){
				
				$scope.s=response;
		
	    })
	}
	
  
	$scope.submitt_community_question=function(){
		$scope.modal.show();
		$scope.loginData.ques=$scope.que;
	
		
		var quali=$scope.quali;
		var que=$scope.que;
		
		var sub_field=$scope.sub_field;
		$scope.loginData.username=localStorage.getItem("loggedin");
		$scope.loginData.email=localStorage.getItem("useremail");
		 
     $scope.email= localStorage.getItem("useremail");
		if(typeof($scope.sub_p_field)!="undefined"){
			
			$scope.loginData.professionfieldd=$scope.sub_p_field;
		}else{
			$scope.loginData.professionfieldd=$scope.subprofession;
		}
		
		if(typeof($scope.ss)!="undefined"){
			$scope.loginData.sectorfieldd=$scope.ss;
		}else{
			$scope.loginData.sectorfieldd=$scope.sub_sector_field;
		}
		if(typeof($scope.que)==""){
			
	
			alert("Please Write Question First");
		}else{
			
			alert("Success");
		}
		
			
		$scope.comsubmitque=function(){
				var user_id=localStorage.getItem("userid");
				
				
 				$http.get("http://api.hauduai.com.ng/ask_question?user_id="+user_id+"&question="+$scope.loginData.ques+"&username="+$scope.loginData.username+"&useremail="+$scope.loginData.email+"&profession="+$scope.loginData.professionfieldd+"&sector="+$scope.loginData.sectorfieldd)
				.success(function(response){
					if(response.status=="success"){
						$scope.modal.hide();
						alert("Your Answer Has Been  Submited");
						window.location.href='/#/app/ask_community';
					}
					else {
						alert("Your Question not Submitted well");
					}
			
				});
			
 
		}
		
		
		
		
	}
	
	 $ionicModal.fromTemplateUrl('templates/popupforcomque.html', {
		scope: $scope
	  }).then(function(modal) {
		$scope.modal = modal;
	  });
	
	$scope.closepop=function(){
	
		$scope.modal.hide();
		$scope.ss="";
		$scope.sub_p_field="";
	}
	
})

 .controller('contactCtrl', function($scope, $ionicModal,$ionicHistory,$http) {
	 	$scope.Submit=function(){
		if($scope.subject==$scope.subject){
			var name=$scope.name;
			//var type="Specialist";
			
			//var lname=$scope.lname;
			//var fullname=fname+" "+lname;
			//var qualified=$scope.qualified;
			//var quali=$scope.quali;
			//var emp_status=$scope.emp_status;
			//var proaffi=$scope.proaffi;
			
			//var sector=$scope.subsector;
			//var subsector=$scope.subsubsector;
			var email=$scope.email;
			var subject=$scope.subject;
			var answertyped=$scope.answertyped;
			
			//var pass=$scope.password;
			//var gettoknow=$scope.gettoknow;
			
			$http.get("http://api.hauduai.com.ng/contact_us?contact_msg="+answertyped+"&contact_name="+name+"&contact_subject="+subject+"&contact_email="+email)
				.success(function(response){
					alert("Your Message Has Been Sent");
					$location.path('/#/app/browse');
				})
				.error(function(){
						alert("Something went Wrong.");
						//alert("You have Registered already.");
						//$location.path('/#/playlists');
				})
			}else{
				alert("Something went Wrong.");
				//$location.path('/#/playlists');
			}
			
		
	}
	/* $scope.Submit=function(){
	var name=$scope.name;
	var email=$scope.email;
	var subject=$scope.subject;
	var answertyped=$scope.answertyped;
	
		$http.get("http://api.hauduai.com.ng/contact_us?contact_name=&contact_email=&contact_subject=&contact_msg="+name+email+subject+answertyped)
			.success(function(response){
				if(response.status=="success"){
						$scope.modal.hide();
						alert("Your Answer Has Been  Submited");
						window.location.href='/#/app/browse';
					}
					else {
						alert("Your Question not Submitted well");
					}
			
				});
	}	 */
}) 
/* .controller('ask_communityCtrl', function($scope, $ionicModal,$ionicHistory,$http) {
	
		$http.get("http://api.hauduai.com.ng/profession")
			.success(function(response){
				$scope.profession=response;
				
	    })
		
		$http.get("http://api.hauduai.com.ng/sector")
			.success(function(response){
				$scope.sector_community=response;
		      
	    })
	
	$scope.changed=function(){
		var id = $scope.subprofession;
		$scope.sub_pro_show=true; 
		$http.get("http://api.hauduai.com.ng/profession_subcategory_name?id="+id)
			.success(function(response){
				
				$scope.qualii=response;
		
	    })
	}
	$scope.changedsector=function(){
		var id = $scope.sub_sector_field;
		  $scope.sub_sec_show=true; 
		$http.get("http://api.hauduai.com.ng/sector_subcategories_name?id="+id)
			.success(function(response){
				
				$scope.s=response;
		
	    })
	}
	
	$scope.submitt_community_question=function(){
		$scope.modal.show();
		$scope.loginData.que=$scope.que;
	
		
		var quali=$scope.quali;
		var que=$scope.que;
		//alert($scope.que);
		var sub_field=$scope.sub_field;
		$scope.loginData.username=localStorage.getItem("loggedin");
		$scope.loginData.email=localStorage.getItem("useremail");
		 
  
     $scope.email= localStorage.getItem("useremail");
		if(typeof($scope.sub_p_field)!="undefined"){
			
			$scope.loginData.professionfieldd=$scope.sub_p_field;
		}else{
			$scope.loginData.professionfieldd=$scope.subprofession;
		}
		
		if(typeof($scope.ss)!="undefined"){
			$scope.loginData.sectorfieldd=$scope.ss;
		}else{
			$scope.loginData.sectorfieldd=$scope.sub_sector_field;
		}
		
			
		$scope.comsubmitque=function(){
				var user_id=localStorage.getItem("userid");
				
				
				
 				$http.get("http://api.hauduai.com.ng/ask_question?user_id="+user_id+"&question="+$scope.loginData.ques+"&username="+$scope.loginData.username+"&useremail="+$scope.loginData.email+"&profession="+$scope.loginData.professionfieldd+"&sector="+$scope.loginData.sectorfieldd)
				.success(function(response){
					if(response.status=="success"){
						$scope.modal.hide();
						alert("your question Submitted well");
					}
			
				})
			
 
		}
		
		
		
		
	}
	
	 $ionicModal.fromTemplateUrl('templates/popupforcomque.html', {
		scope: $scope
	  }).then(function(modal) {
		$scope.modal = modal;
	  });
	
	$scope.closepop=function(){
	
		$scope.modal.hide();
		$scope.ss=undefined;
		$scope.sub_p_field=undefined;
	}
	
}) */

.controller('que_ansCtrl', function($scope, $ionicHistory,$stateParams,$http) {
	$scope.alter=false;
	$scope.alter1=true;
		var id=$stateParams.id;
		$http.get("http://api.hauduai.com.ng/que_ans?id="+id)
			.success(function(response){
			  
			  if(response.length > 0){
				  
				 $scope.qu_an=response; 
				 
			  }
				else{
					//alert("No Answer for this Questions");
				    //location.href="#/app/questions";
					$scope.alter=true;
					$scope.alter1=false;
					
					
				}
				
					
		    })
			
	$scope.go_back=function(){
	    $ionicHistory.goBack();
     }
	
	
})
.controller('newCtrl', function($scope, $ionicHistory,$http) {
	$http.get("http://api.hauduai.com.ng/Recentquestion")
			.success(function(response){
				 for(var i=0;i<=response.length-1;i++){
						//console.log(response[i]);
				} 
			  
			  $scope.listque=response;
			 
				
					
		    })
			 
	
})
.controller('answeresctrl', function($scope, $ionicHistory,$http,$stateParams) {
	var a =$stateParams.id;
	$scope.id =$stateParams.id;
	$scope.answer_notavail=false;
	$scope.answer_avail=false;
	$http.get("http://api.hauduai.com.ng/incview?id="+a)
			.success(function(response){
				 
				
					
		    })
	$http.get("http://api.hauduai.com.ng/answeres?id="+a)
			.success(function(response){
				/*    for(var i=0;i<=response.length-1;i++){
						console.log(response[i]);
				}  */  
			  
			  $scope.que=response[0];
				
					
		    })
			$scope.livenks=[];
			$scope.noMoreItemsAvailable = true;
		$scope.loadolder=function(){	
			 var params={};
				  if( $scope.livenks.length > 0){
					 var val=$scope.livenks.length-1;
					
				  }else{
					var val='0';
					
				  } 
		  
			$http.get("http://api.hauduai.com.ng/answeress?id="+a+"&offset="+val)
			.success(function(response){
				

				 if(response==""){
					 $scope.answer_notavail=true;
					  $scope.noMoreItemsAvailable = false;
					  alert("No More Answers");
				 }else{
					 $scope.answer_avail=true;
					
					 angular.forEach(response , function(child){
							$scope.livenks.push({ans:child.answer,
							name:child.user_name,
							
						  });
						 
					}) 
				 }
				$scope.$broadcast('scroll.infiniteScrollComplete');
				 
									
		    });
			
               
          
		};	 
	
})
.controller('answeresssctrl', function($scope, $ionicHistory,$http,$stateParams,$location) {
	
	/* var value;
localStorage.setItem('key', value); */
	var a =$stateParams.id;
	//var que=$scope.que;
	$scope.aa =$stateParams.id;
	$scope.answer_notavail=false;
	$scope.answer_avail=false;
	$http.get("http://api.hauduai.com.ng/answeres?id="+a)
			.success(function(response){
				  for(var i=0;i<=response.length-1;i++){
						//console.log(response[i]);
				}  
			  
			  $scope.que=response[0];
			 // alert(  $scope.que);
					
		    })
			
			/*  $http.get("http://api.hauduai.com.ng/count_ques_limit")
			.success(function(response){
				
				$scope.question=response.setting_value ;
				var a="question |htmlToPlaintext";
				$scope.qus=a;
				
				
			}) 	 */	
			$http.get("http://api.hauduai.com.ng/answeress?id="+a)
			.success(function(response){
				  

				 if(response==""){
					 $scope.totalans=0;
				 }else{
					 $scope.answer_avail=true;
					$scope.totalans=response.length;
				 }
				
					
		    })
			 $http.get("http://api.hauduai.com.ng/count_answeres?id="+a)
			
			.success(function(response){
				  
			/* $scope.count_answer=response;
				 if(response=="0"){
					 $scope.count_answer="";
				 }else{
					 $scope.answer_avail=true;
			 */		$scope.count_answeres=response.length;
					//alert($scope.count_answeres);
					$location.href="#/app/questioncomm";
				 
				
					
		    }) 
			//var s = '"something"';
             //var result = JSON.parse(s);
			$scope.doSubmit=function(){
				var answertyped=$scope.answertyped;
				var uname=localStorage.getItem('loggedin');
				var uid=localStorage.getItem('userid');
				var email=localStorage.getItem('useremail');
				
				$http.get("http://api.hauduai.com.ng/writeans?ans="+answertyped+"&uid="+uid+"&email="+email+"&uname="+uname+"&qid="+a)
					.success(function(response){
						  
                     alert("Your Answer Has Been  Submited");
					 
					window.location.href='#/app/recentans';
						
							
				 }) ;
				
			}
			
			 
	
})

.controller('ansctrl', function($scope, $ionicHistory,$http,$stateParams,$location) {
	
	/* var value;
localStorage.setItem('key', value); */
	var a =$stateParams.id;
	//var que=$scope.que;
	$scope.aa =$stateParams.id;
	$scope.answer_notavail=false;
	$scope.answer_avail=false;
	$http.get("http://api.hauduai.com.ng/answeres?id="+a)
			.success(function(response){
				  for(var i=0;i<=response.length-1;i++){
						//console.log(response[i]);
				}  
			  
			  $scope.que=response[0];
			 // alert(  $scope.que);
					
		    })
			
			/*  $http.get("http://api.hauduai.com.ng/count_ques_limit")
			.success(function(response){
				
				$scope.question=response.setting_value ;
				var a="question |htmlToPlaintext";
				$scope.qus=a;
				
				
			}) 	 */	
			$http.get("http://api.hauduai.com.ng/answeress?id="+a)
			.success(function(response){
				  

				 if(response==""){
					 $scope.totalans=0;
				 }else{
					 $scope.answer_avail=true;
					$scope.totalans=response.length;
				 }
				
					
		    })
			 $http.get("http://api.hauduai.com.ng/count_answeres?id="+a)
			
			.success(function(response){
				  
			/* $scope.count_answer=response;
				 if(response=="0"){
					 $scope.count_answer="";
				 }else{
					 $scope.answer_avail=true;
			 */		$scope.count_answeres=response.length;
					//alert($scope.count_answeres);
					//$location.href="#/app/new";
				 
				
					
		    }) 
			//var s = '"something"';
             //var result = JSON.parse(s);
			$scope.doSubmit=function(){
				var answertyped=$scope.answertyped;
				var uname=localStorage.getItem('loggedin');
				var uid=localStorage.getItem('userid');
				var email=localStorage.getItem('useremail');
				
				$http.get("http://api.hauduai.com.ng/writeans?ans="+answertyped+"&uid="+uid+"&email="+email+"&uname="+uname+"&qid="+a)
					.success(function(response){
						  
                     alert("Your Answer Has Been  Submited ");
					 
					window.location.href='#/app/new';
						
							
				 }) ;
				
			}
			
			 
	
})

.controller('anserCtrl', function($scope, $ionicHistory,$http,$stateParams,$location) {
	
	/* var value;
localStorage.setItem('key', value); */
	var a =$stateParams.id;
	//var que=$scope.que;
	$scope.aa =$stateParams.id;
	$scope.answer_notavail=false;
	$scope.answer_avail=false;
	$http.get("http://api.hauduai.com.ng/answeres?id="+a)
			.success(function(response){
				  for(var i=0;i<=response.length-1;i++){
						//console.log(response[i]);
				}  
			  
			  $scope.que=response[0];
			 // alert(  $scope.que);
					
		    })
			
			/*  $http.get("http://api.hauduai.com.ng/count_ques_limit")
			.success(function(response){
				
				$scope.question=response.setting_value ;
				var a="question |htmlToPlaintext";
				$scope.qus=a;
				
				
			}) 	 */	
			$http.get("http://api.hauduai.com.ng/answeress?id="+a)
			.success(function(response){
				  

				 if(response==""){
					 $scope.totalans=0;
				 }else{
					 $scope.answer_avail=true;
					$scope.totalans=response.length;
				 }
				
					
		    })
			 $http.get("http://api.hauduai.com.ng/count_answeres?id="+a)
			
			.success(function(response){
				  
			/* $scope.count_answer=response;
				 if(response=="0"){
					 $scope.count_answer="";
				 }else{
					 $scope.answer_avail=true;
			 */		$scope.count_answeres=response.length;
					//alert($scope.count_answeres);
					//$location.href="#/app/new";
				 
				
					
		    }) 
			//var s = '"something"';
             //var result = JSON.parse(s);
			$scope.doSubmit=function(){
				var answertyped=$scope.answertyped;
				var uname=localStorage.getItem('loggedin');
				var uid=localStorage.getItem('userid');
				var email=localStorage.getItem('useremail');
				
				$http.get("http://api.hauduai.com.ng/writeans?ans="+answertyped+"&uid="+uid+"&email="+email+"&uname="+uname+"&qid="+a)
					.success(function(response){
						  
                     alert("Your Answer Has Been  Submited");
					 
					window.location.href='#/app/mostresponse';
						
							
				 }) ;
				
			}
			
			 
	
})
.controller('mostrespCtrl', function($scope, $ionicHistory,$http) {
	$http.get("http://api.hauduai.com.ng/MostAnswer")
			.success(function(response){
				/* for(var i=0;i<=response.length-1;i++){
						console.log(response[i]);
				} */
			  
			  $scope.listque=response;
				//alert( $scope.listque);
					
		    })
			 
	
})
.controller('noansCtrl', function($scope, $ionicHistory,$http,$timeout) {
	$timeout(function () {
    
	$http.get("http://api.hauduai.com.ng/noAnswer")
			.success(function(response){
				/* for(var i=0;i<=response.length-1;i++){
						console.log(response[i]);
				} */
			  
			  $scope.listque=response;
				
					
		    })
	 }, 2000);
	
	$scope.getsubspe_area2=function(){
		  $ionicLoading.show({
    content: 'Loading',
    animation: 'fade-in',
    showBackdrop: true,
    maxWidth: 200,
    showDelay: 0,
	
  });
	}
})
.controller('recentansCtrl', function($scope, $ionicHistory,$http) {
	$http.get("http://api.hauduai.com.ng/RecentAnswered")
			.success(function(response){
				for(var i=0;i<=response.length-1;i++){
						//console.log(response[i]);
				}
			  
			  $scope.listque=response;
				
					
		    })
			
	
})
.controller('BrowseCtrl', function($scope, $ionicHistory) {
	//$ionicHistory.clearHistory();
	$scope.name=localStorage.getItem("loggedin");
	$scope.userid=localStorage.getItem("userid");
	
});


  

